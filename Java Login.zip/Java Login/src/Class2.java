import java.util.HashMap;
public class Class2 {
HashMap<String,String> Register=new HashMap<String,String>();
{
	Register.put("username123","abcd123@");
}
public HashMap<String,String> getInfo()
{
	return Register;
}
}




