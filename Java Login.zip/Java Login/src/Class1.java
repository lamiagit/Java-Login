public class Class1 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Class2 class2obj=new Class2();
Class3 class3obj=new Class3(class2obj.getInfo());
	}
}




