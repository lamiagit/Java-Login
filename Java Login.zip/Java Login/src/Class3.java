import java.util.HashMap;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;
public class Class3 implements ActionListener{
HashMap<String,String> Registered=new HashMap<String,String>();
JFrame Frame=new JFrame();
JLabel Messagelabel=new JLabel("The username is @username123 & the password is abcd123@.");
JLabel Confirmlabel=new JLabel();
JLabel Usernamelabel=new JLabel("Username:");
JLabel Passwordlabel=new JLabel("Password:");
JTextField Usernamefield=new JTextField();
JPasswordField Passwordfield=new JPasswordField();
JButton Loginbutton=new JButton("Login");
JButton Resetbutton=new JButton("Reset");
public Class3(HashMap<String,String> class3paramet)
{
	Registered=class3paramet;
	Frame.setLayout(null);
	Frame.setSize(500,500);
	Frame.setVisible(true);
	Frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	Messagelabel.setBounds(50,250,500,50);
	Confirmlabel.setBounds(180,300,500,50);
	Usernamelabel.setBounds(100,100,75,25);
	Passwordlabel.setBounds(100,150,75,25);
	Usernamefield.setBounds(200,100,150,25);
	Passwordfield.setBounds(200,150,150,25);
	Loginbutton.setBounds(150,200,75,25);
	Loginbutton.addActionListener(this);
	Resetbutton.setBounds(250,200,75,25);
	Resetbutton.addActionListener(this);
	Frame.add(Messagelabel);
	Frame.add(Confirmlabel);
	Frame.add(Usernamelabel);
	Frame.add(Passwordlabel);
	Frame.add(Usernamefield);
	Frame.add(Passwordfield);
	Frame.add(Loginbutton);
	Frame.add(Resetbutton);
}
@Override
public void actionPerformed(ActionEvent e)
{
	if(e.getSource()==Loginbutton)
	{
		String Usernam=Usernamefield.getText();
		String Password=String.valueOf(Passwordfield.getPassword());
		if(Usernam.isEmpty())//regist kora thakte pare, nao pare
		{
			Confirmlabel.setForeground(Color.RED);
			Confirmlabel.setText("Enter username first");
		}
		else if(Registered.containsKey(Usernam))//chinte parar por
		{
			if(Password.isEmpty())
			{
				Confirmlabel.setForeground(Color.RED);
				Confirmlabel.setText("Enter password first");
			}
			else if(Registered.get(Usernam).equals(Password))
			{
				Confirmlabel.setForeground(Color.GREEN);
				Confirmlabel.setText("Login successful");
				Frame.dispose();
				Class4 class4obj=new Class4(Usernam);
			}
			else
			{
				Confirmlabel.setForeground(Color.RED);
				Confirmlabel.setText("Wrong passowrd");
			}
		}
		else
		{
			Confirmlabel.setForeground(Color.RED);
			Confirmlabel.setText("You haven't registered yet");
		}
	}
	if(e.getSource()==Resetbutton)
	{
		Confirmlabel.setText("");
		Usernamefield.setText("");
		Passwordfield.setText("");
	}
}
}
