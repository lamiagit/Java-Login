import javax.swing.JFrame;
import javax.swing.JLabel;
public class Class4 {
	JFrame Welframe=new JFrame();
	JLabel Welcomelabel=new JLabel();
public Class4(String Usernami)
{
	Welframe.setLayout(null);
	Welframe.setSize(500,500);
	Welframe.setVisible(true);
	Welframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	Welcomelabel.setBounds(170,150,500,50);
	Welcomelabel.setText("Welcome, @"+Usernami+".");
	Welframe.add(Welcomelabel);
}
}






